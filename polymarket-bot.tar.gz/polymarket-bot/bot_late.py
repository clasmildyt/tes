"""
bot_late.py  (v4.2 — data-driven profit optimization)
===========================================
Late Entry Speed Bot — enter ONLY in the last 90s of a 5-minute Polymarket window.

CHANGELOG:
  v4.2 (2026-04-29):
  [D1] F2 DOWN: $15→$10 (blocked data: dist 25-30 = 73% would_win).
  [D2] F3 RELAX: LIQ_RECENT $15k→$5k, LIQ_SUSTAINED $50k→$20k
       (94% dari 369 blocked F3 would_have_WON — filter terlalu ketat).
  [D3] MAX_BET_ODDS=0.92: tolak bet jika odds >0.92 (payout <8.7%).
  [D4] SESSION_BLOCK jam 14:55–16:00 UTC (+$6.97 simulasi dari data).
  [D5] Polymarket V2 → polymarket.py pakai py-clob-client-v2.

  v4.1 (2026-04-26):
  [FIX-A] result_tracker.py: PnL dihitung dari odds aktual (1/odds−1), bukan 70% flat.
          Dashboard sebelumnya menampilkan $72.60 padahal profit nyata $6.73 (10× salah!).
  [FIX-B] polymarket.py: BET_MAX_RETRIES 5 → 3. Worst-case retry turun 5s → 450ms.
  [FIX-C] VERSION string di semua log & dashboard agar mudah melacak versi aktif.

  v4.0:
  [P1] F5 filter keras: odds < MIN_BET_ODDS (0.55) → tolak bet.
  [P2] place_bet_on_market() — skip find_active HTTP call (hemat 100–500ms).
  [P3] await _execute_bet — eliminasi event loop queue delay.
  [P4] F2 beat distance DOWN $30→$15, UP tetap $30.
  [P5] Timestamp + odds drift logging di _execute_bet.
  [P6] OI filter signal.py relax: "must decrease" → "max +0.5% naik".

  v3.0:
  [BUG-1] Fix AttributeError _bets_this_hour().
  [BUG-2] Fix dashboard beku: update_filters_live() dari main loop.
"""

BOT_VERSION = "v4.2"   # dipakai di log startup dan dashboard

import asyncio
import logging
import os
import sys
import time

if sys.platform == "win32":
    import msvcrt
    import winsound
else:
    msvcrt   = None
    winsound = None
from collections import deque
from datetime import datetime, timezone

from dotenv import load_dotenv
load_dotenv()


# ─────────────────────────────────────────────
# Sound notifications
# ─────────────────────────────────────────────
def _beep(freq: int, duration: int):
    try:
        if winsound:
            winsound.Beep(freq, duration)
    except Exception:
        pass


async def play_sound(event: str):
    loop = asyncio.get_event_loop()
    if event == "signal":
        await loop.run_in_executor(None, _beep, 600, 120)
        await loop.run_in_executor(None, _beep, 900, 180)
    elif event == "win":
        await loop.run_in_executor(None, _beep, 600, 100)
        await loop.run_in_executor(None, _beep, 800, 100)
        await loop.run_in_executor(None, _beep, 1050, 250)
    elif event == "loss":
        await loop.run_in_executor(None, _beep, 500, 200)
        await loop.run_in_executor(None, _beep, 300, 350)
    elif event == "blocked":
        await loop.run_in_executor(None, _beep, 440, 100)
    elif event == "warning":
        for _ in range(2):
            await loop.run_in_executor(None, _beep, 880, 200)
            await loop.run_in_executor(None, _beep, 440, 200)
        await loop.run_in_executor(None, _beep, 440, 400)


# ── Config ──
DRY_RUN               = os.getenv("DRY_RUN", "true").lower() == "true"
BET_AMOUNT            = float(os.getenv("LATE_BET_AMOUNT", "2.0"))
MIN_ODDS              = float(os.getenv("MIN_ODDS", "0.45"))
MAX_ODDS              = float(os.getenv("LATE_MAX_ODDS", "0.95"))
LIQ_THRESHOLD         = float(os.getenv("LIQUIDATION_THRESHOLD", "200000"))
CLAIM_CASH_THRESHOLD  = float(os.getenv("CLAIM_CASH_THRESHOLD", "4.0"))
CLAIM_CHECK_INTERVAL  = int(os.getenv("CLAIM_CHECK_INTERVAL", "90"))

ENTRY_WINDOW_START    = 210      # only enter at t>=210s
MIN_WINDOW_REMAINING  = 10       # skip if <10s left

# [P4 UPDATE] F2 beat distance — diperbarui dari data aktual 831 blocked signals:
#   DOWN: dist 25-30 punya 73% would_win → $15 masih terlalu ketat → turun ke $10
#   UP:   tetap $30
MIN_BEAT_DISTANCE_UP   = 30.0
MIN_BEAT_DISTANCE_DOWN = 10.0

# [F5 UPDATE] Filter odds GANDA: min DAN max.
# Data: odds > 0.90 punya payout < 11% → 93% win rate dibutuhkan untuk impas.
# Data jam 05/15/18-20 UTC sebagian besar odds tinggi + banyak loss.
# MIN_BET_ODDS: tolak jika odds terlalu rendah (tidak ada keyakinan pasar)
# MAX_BET_ODDS: tolak jika odds terlalu tinggi (payout terlalu kecil untuk worth it)
MIN_BET_ODDS          = float(os.getenv("MIN_BET_ODDS", "0.50"))
MAX_BET_ODDS          = float(os.getenv("MAX_BET_ODDS", "0.92"))  # [NEW] tolak odds > 0.92

LIQ_RECENT_WINDOW     = 3
# [F3 RELAX DATA] 94% dari 369 sinyal blocked F3 would_have_WON!
# Filter liq $15k/$50k terlalu ketat. Turunkan:
# LIQ_RECENT: $15k → $5k, LIQ_SUSTAINED: $50k → $20k
LIQ_RECENT_MIN_USD    = 5_000
LIQ_SUSTAINED_WINDOW  = 30
LIQ_SUSTAINED_MIN_USD = 20_000

CVD_SHORT_WINDOW      = 30       # konfirmasi momentum 30s
CVD_SHORT_THRESHOLD   = 8_000    # $8k dalam 30s
CVD_MIN_THRESHOLD     = 25_000   # threshold CVD 2 menit

ODDS_AGGRESSIVE_FROM  = 180      # mulai aggressive poll di t>=180s
ODDS_POLL_INTERVAL    = 2        # poll setiap 2s saat aggressive
ODDS_NORMAL_INTERVAL  = 10       # poll normal

MAX_BETS_PER_HOUR     = 8
WS_RESTART_SEC        = 60    # restart WebSocket jika ERR lebih dari N detik
DAILY_STOP_LOSS_PCT   = 0.20

# ── Session transition blackout (UTC) ──
SESSION_BLOCK_ENABLED = os.getenv("SESSION_BLOCK", "true").lower() == "true"
SESSION_BLOCKS = [
    ( 7, 55,  9,  5),   # Asian → London open
    (12, 55, 14,  5),   # London → NY open
    (14, 55, 16,  0),   # [DATA] jam 15 UTC = -$3.57 PnL terburuk dari 201 bets
    (20, 55, 22,  5),   # NY close
]

# ── Logging ──
os.makedirs("logs", exist_ok=True)
logging.basicConfig(
    level=logging.WARNING,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("logs/late_live.log", encoding="utf-8"),
        logging.StreamHandler(),
    ]
)
logging.getLogger("engine.signal").setLevel(logging.ERROR)
logging.getLogger("engine.result_tracker").setLevel(logging.INFO)
logging.getLogger("executor.polymarket").setLevel(logging.WARNING)
logger = logging.getLogger(__name__)

from fetcher.hyperliquid_ws import (
    MarketData, HyperliquidWSFetcher,
    get_liquidations_in_window, get_cvd_change,
)
from fetcher.hyperliquid_rest import HyperliquidRESTFetcher
from fetcher.candle_tracker import CandleTracker
from engine.signal import SignalEngine, Signal, SignalResult
from engine.result_tracker import ResultTracker
from engine.blocked_tracker import BlockedTracker
from executor.polymarket import PolymarketExecutor
from utils.colors import (
    C, green, red, yellow, cyan, magenta, white,
    dim, bold, signed_color, ok_or_err,
)


# ─────────────────────────────────────────────
# Session Transition Guard
# ─────────────────────────────────────────────
def _in_session_block() -> tuple:
    """Returns (is_blocked: bool, label: str)."""
    if not SESSION_BLOCK_ENABLED:
        return False, ""
    now   = datetime.now(timezone.utc)
    total = now.hour * 60 + now.minute
    for (h0, m0, h1, m1) in SESSION_BLOCKS:
        start = h0 * 60 + m0
        end   = h1 * 60 + m1
        if start <= total < end:
            return True, f"{h0:02d}:{m0:02d}–{h1:02d}:{m1:02d} UTC"
    return False, ""


# ─────────────────────────────────────────────
# Late Entry Handler
# ─────────────────────────────────────────────
class LateHandler:
    """
    Handles UP/DOWN signals with INSTANT filter pipeline (no delay).
    Enters only in last 90s of window (t=210-300s).

    Filter Pipeline (all checks <1s):
      F1: Entry zone     — elapsed >= 210s AND remaining >= 10s
      F2: Beat distance  — |price - beat| >= $30 in signal direction
      F3: Dual liq       — liq_recent(3s) >= $15k AND liq_sustained(30s) >= $50k
      F4: CVD dual       — cvd_30s aligned AND cvd_2min aligned (both must pass)
      F5: Odds           — info only, NO FILTER

    v3 fixes:
      [BUG-1] _bets_this_hour() sekarang method tersendiri yang benar
      [BUG-2] update_filters_live() update F1-F5 secara live dari main loop,
              tidak bergantung pada sinyal atau session block
    """

    def __init__(
        self,
        tracker:      ResultTracker,
        candle:       CandleTracker,
        data:         MarketData,
        blocked:      BlockedTracker,
        executor:     PolymarketExecutor,
        market_cache: dict,
    ):
        self.tracker      = tracker
        self.candle       = candle
        self.data         = data
        self.blocked      = blocked
        self.executor     = executor
        self.market_cache = market_cache

        self._last_window_id:  str   = ""
        self._window_lock            = asyncio.Lock()
        self._bet_timestamps:  deque = deque(maxlen=MAX_BETS_PER_HOUR)
        self._daily_start_balance: float = 0.0
        self._daily_pnl:       float = 0.0

        # Filter status strings — diupdate oleh update_filters_live() dan on_signal()
        self.f1_status:        str = dim("─ waiting")
        self.f2_status:        str = dim("─ waiting")
        self.f3_status:        str = dim("─ waiting")
        self.f4_status:        str = dim("─ waiting")
        self.f5_status:        str = dim("─ waiting")
        self.last_skip_reason: str = ""

        # Arah terakhir dari sinyal — dipakai update_filters_live sebagai konteks tampilan
        self._last_signal_direction: str = "DOWN"

        self.auto_enabled: bool = True
        self._manual_msg:  str  = ""

    # ── [FIX BUG-1] Method ini harus berdiri sendiri, tidak boleh
    #    masuk ke dalam method lain. Versi sebelumnya crash karena
    #    kode ini nyasar ke dalam update_filters_live() tanpa 'def'. ──
    def _bets_this_hour(self) -> int:
        """Hitung bet yang terpasang dalam 1 jam terakhir."""
        cutoff = time.time() - 3600
        return sum(1 for t in self._bet_timestamps if t > cutoff)

    # ── [FIX BUG-2] Method ini dipanggil dari main loop setiap 1-5 detik.
    #    Filter display selalu ter-update meski session block aktif atau
    #    belum ada sinyal yang lolos. ──
    def update_filters_live(self):
        """
        Update status F1-F5 secara live dari main loop.
        Independen dari on_signal — dashboard tidak pernah beku.
        """
        direction = self._last_signal_direction
        elapsed   = CandleTracker.get_time_elapsed()
        remaining = CandleTracker.get_time_remaining()

        # F1
        if elapsed < ENTRY_WINDOW_START:
            self.f1_status = yellow(f"t={elapsed}s (entry pd t={ENTRY_WINDOW_START}s)")
        elif remaining < MIN_WINDOW_REMAINING:
            self.f1_status = red(f"t={elapsed}s sisa={remaining}s < {MIN_WINDOW_REMAINING}s")
        else:
            self.f1_status = green(f"t={elapsed}s ENTRY ZONE (sisa={remaining}s)")

        # F2
        beat_p    = self.candle.beat_price if self.candle._initialized else 0.0
        cur_price = self.data.btc_price
        if beat_p > 0 and cur_price > 0:
            vs_beat  = cur_price - beat_p
            min_dist = MIN_BEAT_DISTANCE_UP if direction == "UP" else MIN_BEAT_DISTANCE_DOWN
            if direction == "UP":
                ok = vs_beat >= min_dist
                self.f2_status = (green if ok else red)(
                    f"${vs_beat:+.1f} vs beat ({'UP ok' if ok else 'UP fail'}, min +${min_dist:.0f})"
                )
            else:
                ok = vs_beat <= -min_dist
                self.f2_status = (green if ok else red)(
                    f"${vs_beat:+.1f} vs beat ({'DN ok' if ok else 'DN fail'}, min -${min_dist:.0f})"
                )
        else:
            self.f2_status = yellow("─ beat=0 (menunggu candle)")

        # F3
        liq_side = "LONG" if direction == "DOWN" else "SHORT"
        liq_r, _ = get_liquidations_in_window(self.data, liq_side, LIQ_RECENT_WINDOW)
        liq_s, _ = get_liquidations_in_window(self.data, liq_side, LIQ_SUSTAINED_WINDOW)
        rc = green if liq_r >= LIQ_RECENT_MIN_USD    else red
        sc = green if liq_s >= LIQ_SUSTAINED_MIN_USD else red
        self.f3_status = (
            rc(f"r({LIQ_RECENT_WINDOW}s):${liq_r:,.0f}") +
            dim(" | ") +
            sc(f"s({LIQ_SUSTAINED_WINDOW}s):${liq_s:,.0f}")
        )

        # F4
        cvd_30s  = get_cvd_change(self.data, CVD_SHORT_WINDOW)
        cvd_2min = get_cvd_change(self.data, 120)
        if direction == "DOWN":
            s_ok = cvd_30s  < -CVD_SHORT_THRESHOLD
            l_ok = cvd_2min < -CVD_MIN_THRESHOLD
        else:
            s_ok = cvd_30s  > CVD_SHORT_THRESHOLD
            l_ok = cvd_2min > CVD_MIN_THRESHOLD
        self.f4_status = (
            (green if s_ok else red)(f"30s={cvd_30s:+,.0f}") +
            dim(" | ") +
            (green if l_ok else red)(f"2m={cvd_2min:+,.0f}")
        )

        # F5
        yes_px    = self.market_cache.get("yes_px", 0.0)
        no_px     = self.market_cache.get("no_px",  0.0)
        cache_age = time.time() - self.market_cache.get("odds_refreshed_at", 0)
        if self.market_cache.get("odds_valid") and 0.05 <= yes_px <= 0.95:
            self.f5_status = cyan(
                f"UP={yes_px:.2f} DN={no_px:.2f} ({cache_age:.0f}s) — NO FILTER"
            )
        else:
            self.f5_status = yellow(f"─ odds wait ({cache_age:.0f}s)")

    async def on_signal(self, result: SignalResult):
        """
        Dipanggil SignalEngine setiap kali sinyal UP/DOWN muncul.
        Semua filter check INSTANT — tidak ada asyncio.sleep.
        Session block hanya mencegah bet, tidak menghentikan evaluasi filter.
        """
        direction = result.signal.value
        self._last_signal_direction = direction   # untuk update_filters_live

        if not self.auto_enabled:
            return

        # Session block — update reason tapi JANGAN return sebelum update filter
        blocked, blk_label = _in_session_block()
        if blocked:
            self.last_skip_reason = f"SESSION BLOCK: {blk_label}"
            return

        window_id = CandleTracker.get_window_id()
        elapsed   = CandleTracker.get_time_elapsed()
        remaining = CandleTracker.get_time_remaining()

        # ── F1: Entry zone ──
        if elapsed < ENTRY_WINDOW_START:
            self.f1_status = yellow(f"t={elapsed}s (masuk di t={ENTRY_WINDOW_START}s)")
            self.last_skip_reason = f"Too early: t={elapsed}s"
            return
        if remaining < MIN_WINDOW_REMAINING:
            self.f1_status = red(f"t={elapsed}s, sisa={remaining}s < {MIN_WINDOW_REMAINING}s")
            self.last_skip_reason = f"Too late: {remaining}s remaining"
            return
        self.f1_status = green(f"t={elapsed}s ENTRY ZONE (sisa={remaining}s)")

        if not self.candle._initialized:
            self.last_skip_reason = "Candle not initialized"
            return

        beat_p    = self.candle.beat_price
        cur_price = self.data.btc_price

        if beat_p == 0.0:
            self.last_skip_reason = "Beat price = 0"
            return

        # ── F2: Beat distance ──
        # [P4] Threshold berbeda per arah: DOWN=$15, UP=$30
        vs_beat = cur_price - beat_p
        if direction == "UP":
            min_dist = MIN_BEAT_DISTANCE_UP
            if vs_beat < min_dist:
                self.f2_status = red(f"${vs_beat:+.1f} vs beat (butuh +${min_dist:.0f})")
                reason = f"Beat dist UP: ${vs_beat:+.1f} (min +${min_dist:.0f})"
                self.last_skip_reason = reason
                self.blocked.add(
                    direction=direction, beat_price=beat_p,
                    btc_at_block=cur_price, window_id=window_id,
                    window_end_ts=CandleTracker.get_window_end().timestamp(),
                    blocked_by="F2", blocked_reason=reason,
                )
                return
            self.f2_status = green(f"${vs_beat:+.1f} vs beat (UP ok, min +${min_dist:.0f})")
        else:
            min_dist = MIN_BEAT_DISTANCE_DOWN
            if vs_beat > -min_dist:
                self.f2_status = red(f"${vs_beat:+.1f} vs beat (butuh -${min_dist:.0f})")
                reason = f"Beat dist DOWN: ${vs_beat:+.1f} (min -${min_dist:.0f})"
                self.last_skip_reason = reason
                self.blocked.add(
                    direction=direction, beat_price=beat_p,
                    btc_at_block=cur_price, window_id=window_id,
                    window_end_ts=CandleTracker.get_window_end().timestamp(),
                    blocked_by="F2", blocked_reason=reason,
                )
                return
            self.f2_status = green(f"${vs_beat:+.1f} vs beat (DN ok, min -${min_dist:.0f})")

        # ── F3: Dual liquidation ──
        liq_side = "LONG" if direction == "DOWN" else "SHORT"
        liq_recent,    _ = get_liquidations_in_window(self.data, liq_side, LIQ_RECENT_WINDOW)
        liq_sustained, _ = get_liquidations_in_window(self.data, liq_side, LIQ_SUSTAINED_WINDOW)

        recent_ok    = liq_recent    >= LIQ_RECENT_MIN_USD
        sustained_ok = liq_sustained >= LIQ_SUSTAINED_MIN_USD

        if not recent_ok or not sustained_ok:
            self.f3_status = (
                (green if recent_ok    else red)(f"r({LIQ_RECENT_WINDOW}s):${liq_recent:,.0f}") +
                dim(" | ") +
                (green if sustained_ok else red)(f"s({LIQ_SUSTAINED_WINDOW}s):${liq_sustained:,.0f}")
            )
            reason = (
                f"Liq [{liq_side}] insuf: "
                f"r=${liq_recent:,.0f}(min ${LIQ_RECENT_MIN_USD:,.0f}) "
                f"s=${liq_sustained:,.0f}(min ${LIQ_SUSTAINED_MIN_USD:,.0f})"
            )
            self.last_skip_reason = reason
            self.blocked.add(
                direction=direction, beat_price=beat_p,
                btc_at_block=cur_price, window_id=window_id,
                window_end_ts=CandleTracker.get_window_end().timestamp(),
                blocked_by="F3", blocked_reason=reason,
            )
            return
        self.f3_status = green(
            f"r({LIQ_RECENT_WINDOW}s):${liq_recent:,.0f} | "
            f"s({LIQ_SUSTAINED_WINDOW}s):${liq_sustained:,.0f}"
        )

        # ── F4: CVD dual-timeframe ──
        cvd_30s  = get_cvd_change(self.data, CVD_SHORT_WINDOW)
        cvd_2min = get_cvd_change(self.data, 120)

        if direction == "DOWN":
            short_ok = cvd_30s  < -CVD_SHORT_THRESHOLD
            long_ok  = cvd_2min < -CVD_MIN_THRESHOLD
        else:
            short_ok = cvd_30s  > CVD_SHORT_THRESHOLD
            long_ok  = cvd_2min > CVD_MIN_THRESHOLD

        if not short_ok or not long_ok:
            self.f4_status = (
                (green if short_ok else red)(f"CVD30s={cvd_30s:+,.0f}") +
                dim(" | ") +
                (green if long_ok  else red)(f"CVD2m={cvd_2min:+,.0f}")
            )
            reason = (
                f"CVD [{direction}]: "
                f"30s={cvd_30s:+,.0f}(thr={CVD_SHORT_THRESHOLD:,.0f}) "
                f"2m={cvd_2min:+,.0f}(thr={CVD_MIN_THRESHOLD:,.0f})"
            )
            self.last_skip_reason = reason
            self.blocked.add(
                direction=direction, beat_price=beat_p,
                btc_at_block=cur_price, window_id=window_id,
                window_end_ts=CandleTracker.get_window_end().timestamp(),
                blocked_by="F4", blocked_reason=reason,
            )
            return
        self.f4_status = green(
            f"CVD30s={cvd_30s:+,.0f} | CVD2m={cvd_2min:+,.0f} aligned {direction}"
        )

        # ── F5: Odds — FILTER KERAS: MIN dan MAX ──
        # [DATA] Analisis 201 bets nyata:
        # - Odds > 0.92: payout < 8.7% → butuh >92% win rate untuk impas
        # - Jam 15 UTC (odds rata-rata tinggi): -$3.57 PnL dari 13 bets
        # - MIN untuk reject odds terlalu rendah (pasar tidak yakin)
        # - MAX untuk reject odds terlalu tinggi (payout tidak worth it)
        market     = self.market_cache.get("market")
        yes_px     = self.market_cache.get("yes_px", 0.0)
        no_px      = self.market_cache.get("no_px",  0.0)
        cache_age  = time.time() - self.market_cache.get("odds_refreshed_at", 0)
        odds_valid = self.market_cache.get("odds_valid", False)

        if market is None or not odds_valid or not (0.05 <= yes_px <= 0.95):
            self.f5_status = yellow(f"⚠ odds tidak valid (cache {cache_age:.0f}s) — SKIP")
            self.last_skip_reason = f"F5: odds cache invalid/stale ({cache_age:.0f}s)"
            return

        odds = yes_px if direction == "UP" else no_px
        payout_pct = (1.0 / odds - 1.0) * 100 if odds > 0 else 0

        if odds < MIN_BET_ODDS:
            self.f5_status = red(
                f"UP={yes_px:.2f} DN={no_px:.2f} [{direction}={odds:.2f}] "
                f"< min {MIN_BET_ODDS:.2f} — REJECT (odds terlalu rendah)"
            )
            reason = f"F5: odds {odds:.3f} < MIN {MIN_BET_ODDS:.2f} (payout {payout_pct:.0f}%)"
            self.last_skip_reason = reason
            self.blocked.add(
                direction=direction, beat_price=beat_p,
                btc_at_block=cur_price, window_id=window_id,
                window_end_ts=CandleTracker.get_window_end().timestamp(),
                blocked_by="F5", blocked_reason=reason,
            )
            return

        if odds > MAX_BET_ODDS:
            # [DATA] Tolak odds terlalu tinggi — payout terlalu kecil
            # Contoh: odds 0.95 = payout 5.3% → butuh 95% win rate untuk impas
            self.f5_status = red(
                f"UP={yes_px:.2f} DN={no_px:.2f} [{direction}={odds:.2f}] "
                f"> max {MAX_BET_ODDS:.2f} — REJECT (payout {payout_pct:.0f}% terlalu kecil)"
            )
            reason = f"F5: odds {odds:.3f} > MAX {MAX_BET_ODDS:.2f} (payout {payout_pct:.0f}%)"
            self.last_skip_reason = reason
            self.blocked.add(
                direction=direction, beat_price=beat_p,
                btc_at_block=cur_price, window_id=window_id,
                window_end_ts=CandleTracker.get_window_end().timestamp(),
                blocked_by="F5", blocked_reason=reason,
            )
            return

        self.f5_status = green(
            f"UP={yes_px:.2f} DN={no_px:.2f} [{direction}={odds:.2f}] "
            f"payout={payout_pct:.0f}% ({cache_age:.0f}s) OK"
        )

        # ── Rate limiting ──
        if self._bets_this_hour() >= MAX_BETS_PER_HOUR:
            self.last_skip_reason = f"Rate limit: {MAX_BETS_PER_HOUR}/hr"
            logger.warning(f"[LATE] Rate limit: {MAX_BETS_PER_HOUR}/hr")
            return

        # ── Atomic window guard ──
        async with self._window_lock:
            if window_id == self._last_window_id:
                return
            self._last_window_id = window_id

        signal_ts = time.time()  # [P5] catat timestamp tepat setelah semua filter pass
        logger.info(
            f"[LATE] ALL PASS {direction} | "
            f"t={elapsed}s rem={remaining}s | "
            f"beat=${beat_p:,.2f} price=${cur_price:,.2f} dist=${vs_beat:+.1f} | "
            f"CVD30s={cvd_30s:+,.0f} CVD2m={cvd_2min:+,.0f} | "
            f"odds={odds:.3f} payout={payout_pct:.0f}% | window={window_id}"
        )

        # [P3] await langsung — tidak pakai create_task agar tidak antri di event loop.
        # Bet dieksekusi segera setelah filter pass, tanpa delay queue 0-50ms.
        await self._execute_bet(result, window_id, direction, beat_p, cur_price, signal_ts)

    async def manual_bet(self, direction: str):
        """Manual bet via keyboard — bypass F1-F4, tetap respek rate limit & window guard."""
        window_id = CandleTracker.get_window_id()
        remaining = CandleTracker.get_time_remaining()

        blocked, blk_label = _in_session_block()
        if blocked:
            self._manual_msg = red(f"✗ MANUAL {direction} — SESSION BLOCK {blk_label}")
            return

        if remaining < 5:
            self._manual_msg = red(f"✗ MANUAL {direction} — window closing ({remaining}s)")
            return

        if self._bets_this_hour() >= MAX_BETS_PER_HOUR:
            self._manual_msg = red(f"✗ MANUAL {direction} — rate limit ({MAX_BETS_PER_HOUR}/hr)")
            return

        async with self._window_lock:
            if window_id == self._last_window_id:
                self._manual_msg = yellow(f"⚠ MANUAL {direction} — already bet window {window_id}")
                return
            self._last_window_id = window_id

        beat_p    = self.candle.beat_price if self.candle._initialized else 0.0
        cur_price = self.data.btc_price
        elapsed   = CandleTracker.get_time_elapsed()

        self._manual_msg = cyan(f"▶ MANUAL {direction} @ ${cur_price:,.0f}  t={elapsed}s")
        logger.info(
            f"[MANUAL] {direction} price=${cur_price:,.2f} "
            f"beat=${beat_p:,.2f} window={window_id}"
        )
        # [P3] await langsung seperti on_signal
        await self._execute_bet(None, window_id, direction, beat_p, cur_price, time.time())

    async def _execute_bet(
        self,
        result:        SignalResult,
        window_id:     str,
        direction:     str,
        beat_p:        float,
        current_price: float,
        signal_ts:     float,      # [P5] timestamp saat filter terakhir pass
    ):
        """
        Place bet (atau simulasi) dan register ke ResultTracker.

        [P2] Pakai place_bet_on_market(market) dengan market dari cache —
             skip find_active_btc_5min() HTTP call yang butuh 100–500ms.
             Market cache sudah direfresh setiap 2s oleh _market_refresh_loop.

        [P5] Log timestamp signal_ts vs bet_ts untuk mengukur actual latency
             dan odds drift. Data ini penting untuk optimasi selanjutnya.
        """
        ctx = f"window={window_id} dir={direction} price=${current_price:,.0f}"
        try:
            market     = self.market_cache.get("market")
            window_end = CandleTracker.get_window_end().timestamp()
            yes_px     = self.market_cache.get("yes_px", 0.5)
            no_px      = self.market_cache.get("no_px",  0.5)
            odds_cache = yes_px if direction == "UP" else no_px

            if not DRY_RUN:
                if market is None:
                    self.last_skip_reason = "market cache kosong saat eksekusi"
                    logger.error(f"[LATE] market=None saat _execute_bet | {ctx}")
                    return

                bet_start_ts = time.time()  # [P5]

                # [P2] Gunakan place_bet_on_market() dengan market dari cache.
                # Ini skip 1 HTTP call find_active_btc_5min() yang ada di place_bet().
                # place_bet_on_market() tetap memanggil get_current_prices() untuk
                # update odds terbaru sebelum submit order — ini diperlukan.
                bet_result = self.executor.place_bet_on_market(
                    market        = market,
                    direction     = direction,
                    amount_usdc   = BET_AMOUNT,
                    signal_reason = (
                        f"LATE F1-F5 passed | {direction} @ ${current_price:,.0f} "
                        f"t={CandleTracker.get_time_elapsed()}s "
                        f"odds_cache={odds_cache:.3f}"
                    ),
                )

                bet_done_ts  = time.time()  # [P5]
                latency_ms   = (bet_done_ts - signal_ts) * 1000
                filter_to_bet_ms = (bet_start_ts - signal_ts) * 1000

                if bet_result is None:
                    self.last_skip_reason = "place_bet_on_market=None (min_odds/dedup/FOK)"
                    logger.error(
                        f"[LATE] place_bet_on_market None | "
                        f"latency={latency_ms:.0f}ms | {ctx}"
                    )
                    return
                if bet_result.status == "FAILED":
                    err = bet_result.error or "unknown"
                    self.last_skip_reason = f"Bet FAILED: {err[:60]}"
                    logger.error(
                        f"[LATE] Bet FAILED | order={bet_result.order_id} "
                        f"err={err} | latency={latency_ms:.0f}ms | {ctx}"
                    )
                    return
                if bet_result.status not in ("FILLED", "MATCHED", "MACHED", "DRY_RUN"):
                    self.last_skip_reason = f"Bet status unexpected: {bet_result.status}"
                    logger.warning(
                        f"[LATE] Unknown status {bet_result.status} | "
                        f"order={bet_result.order_id} | {ctx}"
                    )
                    return

                # [P5] Hitung actual odds yang dipakai vs odds dari cache saat signal
                odds_actual = bet_result.odds if hasattr(bet_result, "odds") else odds_cache
                odds_drift  = odds_actual - odds_cache

                logger.warning(
                    f"[LATE] ✓ BET PLACED {direction} ${BET_AMOUNT:.2f} | "
                    f"odds_cache={odds_cache:.3f} odds_actual={odds_actual:.3f} "
                    f"drift={odds_drift:+.4f} | "
                    f"filter→submit={filter_to_bet_ms:.0f}ms "
                    f"total={latency_ms:.0f}ms | "
                    f"order={bet_result.order_id} | {ctx}"
                )
            else:
                bet_start_ts     = time.time()
                bet_done_ts      = time.time()
                latency_ms       = (bet_done_ts - signal_ts) * 1000
                filter_to_bet_ms = (bet_start_ts - signal_ts) * 1000
                odds_actual      = odds_cache
                odds_drift       = 0.0
                logger.info(
                    f"[LATE][DRY] BET SIM {direction} ${BET_AMOUNT:.2f} @ {odds_cache:.3f} | "
                    f"latency={latency_ms:.0f}ms | {ctx}"
                )

            # Simpan odds_drift ke last_skip_reason sebagai info dashboard
            self.last_skip_reason = (
                f"✓ BET {direction} @ {odds_actual:.3f} "
                f"drift={odds_drift:+.4f} lat={latency_ms:.0f}ms"
            )

            self._bet_timestamps.append(time.time())
            self.tracker.add(
                direction     = direction,
                btc_entry     = current_price,
                beat_price    = beat_p,
                window_id     = window_id,
                window_end_ts = window_end,
                amount_usdc   = BET_AMOUNT,
                odds          = odds_actual,
                on_resolved   = self._on_resolved,
            )
            asyncio.create_task(play_sound("signal"))

        except Exception as e:
            logger.error(f"[LATE] _execute_bet exception: {e} | {ctx}", exc_info=True)

    async def _on_resolved(
        self,
        direction: str,
        is_win:    bool,
        btc_entry: float,
        btc_exit:  float,
    ):
        result_str = green("WIN") if is_win else red("LOSS")
        logger.info(
            f"[LATE] Resolved {direction} {result_str} | "
            f"entry ${btc_entry:,.0f} → exit ${btc_exit:,.0f}"
        )
        asyncio.create_task(play_sound("win" if is_win else "loss"))


# ─────────────────────────────────────────────
# Market refresh loop
# ─────────────────────────────────────────────
async def _market_refresh_loop(executor: PolymarketExecutor, market_cache: dict):
    """
    Poll Polymarket untuk market aktif dan odds terbaru.
    Aggressive polling mulai t>=180s. Exponential backoff saat error.
    """
    loop         = asyncio.get_event_loop()
    error_streak = 0
    MAX_BACKOFF  = 30

    while True:
        try:
            elapsed = CandleTracker.get_time_elapsed()
            is_agg  = (elapsed >= ODDS_AGGRESSIVE_FROM) or \
                      (CandleTracker.get_time_remaining() < 100)
            poll_interval = ODDS_POLL_INTERVAL if is_agg else ODDS_NORMAL_INTERVAL

            mkt = await loop.run_in_executor(
                None, executor.finder.find_active_btc_5min
            )
            market_cache["market"]       = mkt
            market_cache["refreshed_at"] = time.time()
            error_streak = 0

            if mkt:
                market_cache["question"] = mkt.question
                try:
                    yes_px, no_px = executor.finder.get_current_prices(mkt)
                    if 0.05 <= yes_px <= 0.95:
                        market_cache["yes_px"]            = yes_px
                        market_cache["no_px"]             = no_px
                        market_cache["odds_refreshed_at"] = time.time()
                        market_cache["odds_valid"]        = True
                    else:
                        market_cache["odds_valid"] = False
                        logger.debug(
                            f"[CACHE] Odds out-of-range: YES={yes_px:.3f} NO={no_px:.3f}"
                        )
                except Exception as e:
                    market_cache["odds_valid"] = False
                    logger.debug(f"[CACHE] Odds fetch error: {e}")

                market_cache["next_question"] = ""
                market_cache["next_secs"]     = 0.0
            else:
                market_cache["question"] = "─ no active market"
                market_cache["yes_px"]   = 0.0
                market_cache["no_px"]    = 0.0
                try:
                    next_mkt, next_secs = await loop.run_in_executor(
                        None, executor.finder.find_next_btc_5min
                    )
                    market_cache["next_question"] = next_mkt.question if next_mkt else ""
                    market_cache["next_secs"]     = next_secs
                except Exception:
                    pass

        except Exception as e:
            error_streak += 1
            backoff = min(2 ** (error_streak - 1), MAX_BACKOFF)
            logger.debug(
                f"[CACHE] Error streak={error_streak} backoff={backoff}s: {e}"
            )
            await asyncio.sleep(backoff)
            continue

        await asyncio.sleep(poll_interval)


# ─────────────────────────────────────────────
# Auto-Claim loop
# ─────────────────────────────────────────────
async def _auto_claim_loop(
    executor:    PolymarketExecutor,
    claim_state: dict,
    tracker:     ResultTracker,
):
    """
    Auto-claim posisi menang + autowrap USDC.e → pUSD.

    Flow tiap siklus:
      1. claim_all_winnings() — redeem CTF token yang menang → pUSD masuk wallet
      2. wrap_usdc_to_pusd()  — jika masih ada USDC.e lama, konversi ke pUSD
      3. Update claim_state["pusd_bal"] untuk dashboard

    Trigger:
      - Setiap CLAIM_CHECK_INTERVAL detik (default 90s)
      - Segera jika cash < CLAIM_CASH_THRESHOLD
    """
    if DRY_RUN:
        claim_state["status"]   = dim("─ DRY RUN (claim off)")
        claim_state["pusd_bal"] = 0.0
        return

    loop       = asyncio.get_event_loop()
    last_check = 0.0

    while True:
        balance    = claim_state.get("last_balance", 999.0)
        time_since = time.time() - last_check
        should_check = (
            last_check == 0.0
            or time_since >= CLAIM_CHECK_INTERVAL
            or (balance < CLAIM_CASH_THRESHOLD and time_since >= 30)
        )

        if not should_check:
            await asyncio.sleep(10)
            continue

        claim_state["status"] = dim("... mengecek posisi...")
        last_check = time.time()
        ts_str = datetime.now().strftime("%H:%M:%S")

        try:
            now              = time.time()
            pending_snapshot = list(tracker._pending)
            active_window_ids = {
                p.window_id
                for p in pending_snapshot
                if p.window_end_ts > now
            }
            if active_window_ids:
                logger.info(f"[CLAIM] Skip active windows: {active_window_ids}")

            # Gunakan autoclaim_and_wrap() — claim + konversi USDC.e lama sekaligus
            result = await loop.run_in_executor(
                None, lambda: executor.autoclaim_and_wrap(
                    skip_window_ids     = active_window_ids,
                    wrap_remaining_usdc = True,
                )
            )

            claimed      = result["claimed"]
            total        = result["total"]
            wrapped      = result["wrapped"]
            pusd_bal     = result["pusd_bal"]

            # Simpan saldo pUSD untuk dashboard
            claim_state["pusd_bal"] = pusd_bal

            # Status string untuk dashboard
            wrap_tag = green(" +wrap✓") if wrapped else ""
            if total == 0:
                claim_state["status"] = dim(f"─ nothing ({ts_str}){wrap_tag}")
            elif claimed > 0:
                claim_state["status"] = green(
                    f"✓ {claimed}/{total} claimed{wrap_tag} | pUSD ${pusd_bal:.2f} ({ts_str})"
                )
                asyncio.create_task(play_sound("win"))
            else:
                claim_state["status"] = yellow(
                    f"⚠ {total} redeemable, 0 claimed ({ts_str})"
                )

        except Exception as e:
            err_str = str(e)
            if "MATIC" in err_str or "insufficient funds" in err_str.lower():
                claim_state["status"] = red("✗ No MATIC for gas! Kirim POL ke wallet")
            elif "web3" in err_str.lower():
                claim_state["status"] = yellow("⚠ web3 tidak ada — pip install web3")
            else:
                claim_state["status"] = red(f"✗ err: {err_str[:45]} ({ts_str})")
            logger.error(f"[CLAIM] Error: {e}")

        await asyncio.sleep(10)


# ─────────────────────────────────────────────
# Dashboard  (compact, fits 80-col terminal)
# ─────────────────────────────────────────────
def print_late_dashboard(
    data:         MarketData,
    engine:       SignalEngine,
    tracker:      ResultTracker,
    uptime:       float,
    candle:       CandleTracker,
    handler:      LateHandler,
    blocked:      BlockedTracker,
    market_cache: dict,
    balance:      float = 0.0,
    claim_status: str   = "",
    claim_state:  dict  = None,   # [NEW] untuk tampil pUSD balance
    ws_err_since: float = 0.0,   # timestamp pertama WS ERR (0 = OK)
):
    os.system("cls" if os.name == "nt" else "clear")

    stats   = tracker.stats
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    up_m    = int(uptime // 60)
    up_s    = int(uptime % 60)
    dry_tag = magenta(" DRY") if DRY_RUN else red(bold(" LIVE"))

    # ── Market data ──
    liq_s3,  _ = get_liquidations_in_window(data, "SHORT", 3)
    liq_l3,  _ = get_liquidations_in_window(data, "LONG",  3)
    liq_s30, _ = get_liquidations_in_window(data, "SHORT", 30)
    liq_l30, _ = get_liquidations_in_window(data, "LONG",  30)
    cvd_30s     = get_cvd_change(data, 30)
    cvd_2m      = get_cvd_change(data, 120)

    ws_str  = ok_or_err(data.ws_connected, "OK", "ERR")
    btc_str = cyan(f"${data.btc_price:,.2f}")
    c30_str = signed_color(cvd_30s, f"${cvd_30s:+,.0f}")
    c2m_str = signed_color(cvd_2m,  f"${cvd_2m:+,.0f}")

    # ── Candle / Window ──
    if candle and candle._initialized:
        cs        = candle.get_status()
        elapsed   = cs.get("time_elapsed", CandleTracker.get_time_elapsed())
        remaining = cs["time_remaining"]
        prog      = cs["progress_pct"]
        wid       = cs["window_id"]
        beat_p    = cs["beat_price"]

        bar_f    = int(prog / 100 * 20)
        prog_bar = cyan("#" * bar_f) + dim("." * (20 - bar_f))

        if beat_p > 0:
            beat_str = cyan(f"${beat_p:,.2f}")
            vs_b     = data.btc_price - beat_p
            bst      = (
                green(f"+${vs_b:,.1f}") if vs_b > 0
                else red(f"-${abs(vs_b):,.1f}") if vs_b < 0
                else dim("FLAT")
            )
        else:
            beat_str = yellow("Waiting...")
            bst      = dim("─")

        if elapsed >= ENTRY_WINDOW_START:
            el_str = green(bold(f"t={elapsed}s ENTRY ZONE"))
        elif elapsed >= ENTRY_WINDOW_START - 30:
            el_str = yellow(f"t={elapsed}s (entry dlm {ENTRY_WINDOW_START-elapsed}s)")
        else:
            el_str = dim(f"t={elapsed}s (entry pd t={ENTRY_WINDOW_START}s)")

        rem_str = (
            red(f"{remaining}s")    if remaining <= MIN_WINDOW_REMAINING
            else yellow(f"{remaining}s") if remaining <= 30
            else green(f"{remaining}s")
        )
    else:
        wid, beat_p, beat_str = "--:--", 0.0, yellow("Waiting...")
        bst = el_str = rem_str = dim("─")
        prog_bar = dim("." * 20)
        elapsed = 0; remaining = 300

    # ── Market cache ──
    mc_age = time.time() - market_cache.get("refreshed_at", 0)
    if market_cache.get("market") is not None:
        age_c  = green(f"{mc_age:.0f}s") if mc_age < 10 else yellow(f"{mc_age:.0f}s")
        mc_str = green(market_cache.get("question", "")[:42]) + dim(f" [{age_c}]")
    else:
        next_q    = market_cache.get("next_question", "")
        next_secs = market_cache.get("next_secs", 0.0)
        if next_q:
            rr = max(0.0, next_secs - mc_age)
            mc_str = dim(f"No market — {int(rr//60)}m{int(rr%60):02d}s: {next_q[-28:]}")
        else:
            mc_str = yellow("No active market")

    # ── Odds ──
    _yp = market_cache.get("yes_px", 0.0)
    _np = market_cache.get("no_px",  0.0)
    _oa = time.time() - market_cache.get("odds_refreshed_at", 0)
    if market_cache.get("odds_valid") and 0.05 <= _yp <= 0.95:
        ys  = (green if _yp >= 0.6 else yellow if _yp >= 0.45 else red)(f"{_yp:.3f}")
        ns  = (green if _np >= 0.6 else yellow if _np >= 0.45 else red)(f"{_np:.3f}")
        odds_str = f"UP={ys} DN={ns} {dim(f'{_oa:.0f}s')}"
    else:
        odds_str = yellow(f"wait ({_oa:.0f}s)")

    # ── Liq colors ──
    def lc(v, thr): return (green if v >= thr else white)(f"${v:>9,.0f}")
    ls3  = lc(liq_s3,  LIQ_RECENT_MIN_USD)
    ll3  = lc(liq_l3,  LIQ_RECENT_MIN_USD)
    ls30 = lc(liq_s30, LIQ_SUSTAINED_MIN_USD)
    ll30 = lc(liq_l30, LIQ_SUSTAINED_MIN_USD)

    # ── Filter strings ──
    f1 = getattr(handler, "f1_status", dim("─"))
    f2 = getattr(handler, "f2_status", dim("─"))
    f3 = getattr(handler, "f3_status", dim("─"))
    f4 = getattr(handler, "f4_status", dim("─"))
    f5 = getattr(handler, "f5_status", dim("─"))
    sk = dim(getattr(handler, "last_skip_reason", "─")[:55])

    # ── Last signal ──
    last = engine.last_signal
    if last:
        sv   = last.signal.value
        st   = datetime.fromtimestamp(last.timestamp).strftime("%H:%M:%S")
        si   = green("UP  ") if sv == "UP" else red("DOWN") if sv == "DOWN" else dim("SKIP")
    else:
        si, st = dim("─"), "-"

    # ── Results ──
    wr   = stats["win_rate"]
    wf   = int(wr / 100 * 20)
    bar  = (
        green("#" * wf) + dim("." * (20 - wf)) if wr >= 60
        else yellow("#" * wf) + dim("." * (20 - wf)) if wr >= 50
        else red("#" * wf) + dim("." * (20 - wf))
    )
    wr_s  = (green if wr >= 60 else yellow if wr >= 50 else red)(f"{wr:.1f}%")
    pnl_s = signed_color(stats["total_pnl"], f"${stats['total_pnl']:+.2f}")
    ws_   = green(str(stats["wins"]))
    ls_   = red(str(stats["losses"]))
    bhr   = handler._bets_this_hour() if handler else 0

    # ── Session / mode ──
    auto_s = green("AUTO") if handler and handler.auto_enabled else yellow("MANUAL")
    sb, sl = _in_session_block()
    sess_s = red(f"[X] {sl}") if sb else (dim("filter OFF") if not SESSION_BLOCK_ENABLED else green("OK"))
    m_msg  = getattr(handler, "_manual_msg", "")

    # ── Blocked ──
    blk_line = ""
    if blocked:
        bs  = blocked.stats
        bac = (green if bs["filter_acc_pct"] >= 70 else yellow if bs["filter_acc_pct"] >= 50 else red)(
            f"{bs['filter_acc_pct']:.1f}%"
        )
        blk_line = (
            f"BLK:{cyan(str(bs['total']))} acc:{bac} "
            f"W:{green(str(bs['would_win']))} L:{red(str(bs['would_loss']))}"
        )

    # ── Pending positions ──
    pending = tracker._pending if tracker else []

    # ── WS status: ERR ditampilkan merah dengan penjelasan ──
    ws_err_dur = 0
    if not data.ws_connected:
        ws_err_dur = int(time.time() - ws_err_since) if ws_err_since > 0 else 0
        ws_str = red(f"ERR {ws_err_dur}s")
    else:
        ws_str = green("OK")

    # ── Print — layout lama: border kiri+kanan, label : nilai ──
    W   = 64   # lebar konten (antara | dan |), total baris = 68
    SEP = f"+{'-'*W}+"

    def pad(content_plain: int, total: int = W - 2) -> str:
        """Kembalikan spasi padding agar baris pas W karakter (tanpa ANSI)."""
        spaces = max(0, total - content_plain)
        return " " * spaces

    def row(label: str, value: str, label_len: int, value_len: int) -> str:
        """Baris: |  LABEL   : VALUE                    |"""
        # Hitung padding berdasarkan panjang plain-text
        inner = f"  {label} : {value}"
        inner_plain_len = 2 + label_len + 3 + value_len
        p = pad(inner_plain_len, W - 2)
        return f"|{inner}{p}  |"

    def sec(title: str) -> str:
        inner = f"  {title}"
        p = pad(2 + len(title), W - 2)
        return f"|{inner}{p}  |"

    # Header
    print(SEP)
    hdr_plain = f"  LATE BOT {BOT_VERSION}"
    hdr_plain += f"  LIVE" if not DRY_RUN else "  DRY RUN"
    hdr_plain += f"  {now_str}  {up_m:02d}m {up_s:02d}s"
    hdr_color = (
        f"  {bold(f'LATE BOT {BOT_VERSION}')}{dry_tag}  "
        f"{cyan(now_str)}  {dim(f'{up_m:02d}m {up_s:02d}s')}"
    )
    p = pad(len(hdr_plain), W - 2)
    print(f"|{hdr_color}{p}  |")

    # ── Tampilkan banner WS ERR jika disconnect ──
    if not data.ws_connected:
        restart_in = max(0, WS_RESTART_SEC - ws_err_dur)
        warn_txt   = (
            f"!! WS DISCONNECT {ws_err_dur}s — data CVD/liq beku! "
            f"Auto-restart dalam {restart_in}s"
        )
        warn_color = red(bold(f"!! WS DISCONNECT {ws_err_dur}s")) + red(" — data CVD/liq BEKU!") + yellow(f" restart dlm {restart_in}s")
        p = pad(2 + len(warn_txt), W - 2)
        print(SEP)
        print(f"|  {warn_color}{p}  |")

    # ── WINDOW ──
    print(SEP)
    # Window ID + Remaining
    wid_plain = f"  Window ID   : {wid}  Remaining: "
    wid_color = f"  {bold('Window ID')}   : {cyan(wid)}  Remaining: "
    rem_plain = f"{remaining}s"
    p = pad(len(wid_plain) + len(rem_plain), W - 2)
    print(f"|{wid_color}{rem_str}{p}  |")

    # Beat price + vs beat
    beat_plain  = f"  Beat price  : ${beat_p:,.2f}  vs beat: "
    vs_plain    = f"+${data.btc_price - beat_p:,.1f}" if data.btc_price > beat_p else f"-${abs(data.btc_price - beat_p):,.1f}" if data.btc_price < beat_p else "FLAT"
    p = pad(len(beat_plain) + len(vs_plain), W - 2)
    print(f"|  {bold('Beat price')}  : {beat_str}  vs beat: {bst}{p}  |")

    # Elapsed
    el_plain = f"t={elapsed}s (entry pd t={ENTRY_WINDOW_START}s)"
    if elapsed >= ENTRY_WINDOW_START:
        el_plain = f"t={elapsed}s ENTRY ZONE"
    elif elapsed >= ENTRY_WINDOW_START - 30:
        el_plain = f"t={elapsed}s (entry dlm {ENTRY_WINDOW_START-elapsed}s)"
    p = pad(2 + len("Elapsed     : ") + len(el_plain), W - 2)
    print(f"|  {bold('Elapsed')}     : {el_str}{p}  |")

    # Market
    mc_plain = market_cache.get("question", "")[:48]
    if market_cache.get("market") is None:
        next_q    = market_cache.get("next_question", "")
        next_secs = market_cache.get("next_secs", 0.0)
        if next_q:
            rr = max(0.0, next_secs - mc_age)
            mc_plain = f"No market — {int(rr//60)}m{int(rr%60):02d}s: {next_q[-28:]}"
        else:
            mc_plain = "No active market"
    p = pad(2 + len("Market      : ") + len(mc_plain), W - 2)
    print(f"|  {bold('Market')}      : {mc_str}{p}  |")

    # ── MARKET DATA ──
    print(SEP)
    # BTC Price + WS
    btc_plain = f"${data.btc_price:,.2f}"
    ws_plain  = "OK" if data.ws_connected else "ERR (reconnecting...)"
    p = pad(2 + len("BTC Price   : ") + len(btc_plain) + len("   WS: ") + len(ws_plain), W - 2)
    print(f"|  {bold('BTC Price')}   : {btc_str}   WS: {ws_str}{p}  |")

    # Odds
    odds_plain = f"UP={_yp:.3f} DOWN={_np:.3f} {_oa:.0f}s ago"
    if not (market_cache.get("odds_valid") and 0.05 <= _yp <= 0.95):
        odds_plain = f"menunggu data... ({_oa:.0f}s)"
    p = pad(2 + len("Odds        : ") + len(odds_plain), W - 2)
    print(f"|  {bold('Odds')}        : {odds_str}{p}  |")

    # CVD 30s
    cvd30_plain = f"${cvd_30s:+,.0f}"
    p = pad(2 + len("CVD 30s     : ") + len(cvd30_plain), W - 2)
    print(f"|  {bold('CVD 30s')}     : {c30_str}{p}  |")

    # CVD 2min
    cvd2m_plain = f"${cvd_2m:+,.0f}"
    p = pad(2 + len("CVD 2min    : ") + len(cvd2m_plain), W - 2)
    print(f"|  {bold('CVD 2min')}    : {c2m_str}{p}  |")

    # Liq SHORT
    ls3_plain  = f"${liq_s3:>9,.0f}"
    ls30_plain = f"${liq_s30:>9,.0f}"
    p = pad(2 + len("Liq SHORT   : 3s=") + len(ls3_plain) + len("  30s=") + len(ls30_plain), W - 2)
    print(f"|  {bold('Liq SHORT')}   : 3s={ls3}  30s={ls30}{p}  |")

    # Liq LONG
    ll3_plain  = f"${liq_l3:>9,.0f}"
    ll30_plain = f"${liq_l30:>9,.0f}"
    p = pad(2 + len("Liq LONG    : 3s=") + len(ll3_plain) + len("  30s=") + len(ll30_plain), W - 2)
    print(f"|  {bold('Liq LONG')}    : 3s={ll3}  30s={ll30}{p}  |")

    # ── FILTERS ──
    print(SEP)
    # F1
    f1_txt = getattr(handler, "f1_status", dim("─"))
    f1_plain = f"t={elapsed}s (entry pd t={ENTRY_WINDOW_START}s)"
    p = pad(2 + len("[F1] Entry zone  : ") + len(f1_plain), W - 2)
    print(f"|  {bold('[F1] Entry zone')}  : {f1_txt}{p}  |")
    hint1 = f"t>={ENTRY_WINDOW_START}s, remaining>={MIN_WINDOW_REMAINING}s"
    p = pad(7 + len(hint1), W - 2)
    print(f"|       {dim(hint1)}{p}  |")

    # F2
    f2_txt = getattr(handler, "f2_status", dim("─"))
    f2_plain = f"$+0.0 vs beat (DN fail, min -${MIN_BEAT_DISTANCE_DOWN:.0f})"
    p = pad(2 + len("[F2] Beat dist   : ") + len(f2_plain), W - 2)
    print(f"|  {bold('[F2] Beat dist')}   : {f2_txt}{p}  |")
    hint2 = f"|dist|>=${MIN_BEAT_DISTANCE_UP:.0f}(UP) / ${MIN_BEAT_DISTANCE_DOWN:.0f}(DN)"
    p = pad(7 + len(hint2), W - 2)
    print(f"|       {dim(hint2)}{p}  |")

    # F3
    f3_txt = getattr(handler, "f3_status", dim("─"))
    f3_plain = f"r(3s):$0 | s(30s):$0"
    p = pad(2 + len("[F3] Liq dual    : ") + len(f3_plain), W - 2)
    print(f"|  {bold('[F3] Liq dual')}    : {f3_txt}{p}  |")
    hint3 = f"r({LIQ_RECENT_WINDOW}s)>=${LIQ_RECENT_MIN_USD/1000:.0f}k, s({LIQ_SUSTAINED_WINDOW}s)>=${LIQ_SUSTAINED_MIN_USD/1000:.0f}k"
    p = pad(7 + len(hint3), W - 2)
    print(f"|       {dim(hint3)}{p}  |")

    # F4
    f4_txt = getattr(handler, "f4_status", dim("─"))
    f4_plain = f"30s=+0 | 2m=+0"
    p = pad(2 + len("[F4] CVD dual    : ") + len(f4_plain), W - 2)
    print(f"|  {bold('[F4] CVD dual')}    : {f4_txt}{p}  |")
    hint4 = f"30s>=${CVD_SHORT_THRESHOLD/1000:.0f}k AND 2min>=${CVD_MIN_THRESHOLD/1000:.0f}k (dual timeframe)"
    p = pad(7 + len(hint4), W - 2)
    print(f"|       {dim(hint4)}{p}  |")

    # F5
    f5_txt = getattr(handler, "f5_status", dim("─"))
    f5_plain = f"UP=0.00 DOWN=0.00 [UP=0.00] (0s) — NO FILTER"
    p = pad(2 + len("[F5] Odds (info) : ") + len(f5_plain), W - 2)
    print(f"|  {bold('[F5] Odds (info)')} : {f5_txt}{p}  |")

    # Last skip
    skip_txt = dim(getattr(handler, "last_skip_reason", "─")[:50])
    skip_plain = getattr(handler, "last_skip_reason", "─")[:50]
    p = pad(2 + len("Last skip    : ") + len(skip_plain), W - 2)
    print(f"|  {bold('Last skip')}    : {skip_txt}{p}  |")

    # ── LAST SIGNAL ──
    print(SEP)
    sig_plain = f"SKIP @ 00:00:00"
    p = pad(2 + len("LAST SIGNAL : ") + len(sig_plain), W - 2)
    print(f"|  {bold('LAST SIGNAL')} : {si}  @ {cyan(st)}{p}  |")

    # ── ACTIVE POSITIONS ──
    print(SEP)
    pos_hdr = f"ACTIVE POSITIONS  ({len(pending)} open)"
    p = pad(2 + len(pos_hdr), W - 2)
    print(f"|  {bold('ACTIVE POSITIONS')}  ({len(pending)} open){p}  |")
    if not pending:
        pnl_empty = "─ tidak ada posisi aktif"
        p = pad(2 + len(pnl_empty), W - 2)
        print(f"|  {dim(pnl_empty)}{p}  |")
    else:
        for pos in pending[-3:]:
            tl  = max(0, pos.window_end_ts - time.time())
            di  = green("^ UP  ") if pos.direction == "UP" else red("v DOWN")
            pay = round((1.0 / pos.odds - 1.0) * pos.amount_usdc, 2) if pos.odds > 0 else 0
            pos_plain = f"^ UP   ${pos.amount_usdc:.2f} @ {pos.odds:.3f} | {pos.window_id} | sisa {tl:.0f}s | +${pay:.2f}"
            pos_color = f"{di} ${pos.amount_usdc:.2f} @ {cyan(f'{pos.odds:.3f}')} | {cyan(pos.window_id)} | sisa {yellow(f'{tl:.0f}s')} | +${pay:.2f}"
            p = pad(2 + len(pos_plain), W - 2)
            print(f"|  {pos_color}{p}  |")

    # ── RESULTS ──
    print(SEP)
    bal_plain = f"${balance:,.2f}"
    dry_label = " (sim)" if DRY_RUN else ""
    p = pad(2 + len("Balance   : ") + len(bal_plain) + len(" USDC") + len(dry_label), W - 2)
    print(f"|  {bold('Balance')}   : {cyan(f'${balance:,.2f}')} USDC{dim(dry_label)}{p}  |")

    # pUSD balance (dari autoclaim_and_wrap hasil terakhir)
    pusd_bal  = claim_state.get("pusd_bal", 0.0) if isinstance(claim_state, dict) else 0.0
    pusd_str  = cyan(f"${pusd_bal:,.4f}") if pusd_bal > 0 else dim("$0.0000")
    pusd_plain = f"${pusd_bal:,.4f} pUSD"
    p = pad(2 + len("pUSD bal  : ") + len(pusd_plain), W - 2)
    #print(f"|  {bold('pUSD bal')}  : {pusd_str}{p}  |")

    claim_plain = claim_status[:38] if claim_status else "─ belum dicek"
    p = pad(2 + len("AutoClaim : OK (thr < $4)"), W - 2)
    if DRY_RUN:
        print(f"|  {bold('AutoClaim')} : {dim('─ DRY (claim off)')}{p}  |")
    elif balance < CLAIM_CASH_THRESHOLD:
        print(f"|  {bold('AutoClaim')} : {yellow('!! LOW CASH — klaim diprioritaskan!')}{p}  |")
    else:
        print(f"|  {bold('AutoClaim')} : {dim(f'OK (thr < ${CLAIM_CASH_THRESHOLD:.0f})')}{p}  |")

    cl_plain = (claim_status if claim_status else "─ belum dicek")[:48]
    p = pad(2 + len("Claim log : ") + len(cl_plain), W - 2)
    print(f"|  {bold('Claim log')} : {dim(cl_plain)}{p}  |")

    bethr_plain = f"{bhr}/{MAX_BETS_PER_HOUR}  Bet size: ${BET_AMOUNT:.2f}"
    p = pad(2 + len("Bets/hour : ") + len(bethr_plain), W - 2)
    print(f"|  {bold('Bets/hour')} : {cyan(str(bhr))}/{MAX_BETS_PER_HOUR}  Bet size: {yellow(f'${BET_AMOUNT:.2f}')}{p}  |")

    res_plain = f"{stats['total']}  (pending: {stats['pending']})  WIN: {stats['wins']} LOSS:  {stats['losses']}"
    p = pad(2 + len("Resolved  : ") + len(res_plain), W - 2)
    print(f"|  {bold('Resolved')}  : {cyan(str(stats['total']))}  (pending: {yellow(str(stats['pending']))})  WIN: {green(str(stats['wins']))} LOSS:  {red(str(stats['losses']))}{p}  |")

    wr_plain = f"{wr:.1f}%  [{('#' * wf) + ('.' * (20 - wf))}]"
    p = pad(2 + len("Win Rate  : ") + len(wr_plain), W - 2)
    print(f"|  {bold('Win Rate')}  : {wr_s}  [{bar}]{p}  |")

    pnl_plain = f"${stats['total_pnl']:+.2f}"
    p = pad(2 + len("Total PnL : ") + len(pnl_plain), W - 2)
    print(f"|  {bold('Total PnL')} : {pnl_s}{p}  |")

    # ── BLOCKED ──
    if blocked:
        bs  = blocked.stats
        bac = (green if bs["filter_acc_pct"] >= 70 else yellow if bs["filter_acc_pct"] >= 50 else red)(
            f"{bs['filter_acc_pct']:.1f}%"
        )
        print(SEP)
        blk_plain = f"BLOCKED  resolved:{bs['total']}  acc:{bs['filter_acc_pct']:.1f}%  WIN:{bs['would_win']} LOSS:{bs['would_loss']}"
        p = pad(2 + len(blk_plain), W - 2)
        print(f"|  {bold('BLOCKED')}  resolved:{cyan(str(bs['total']))}  acc:{bac}  WIN:{green(str(bs['would_win']))} LOSS:{red(str(bs['would_loss']))}{p}  |")

    # ── MODE / SESSION ──
    print(SEP)
    auto_plain = "AUTO OK" if handler and handler.auto_enabled else "MANUAL (auto OFF)"
    p = pad(2 + len("MODE    : ") + len(auto_plain), W - 2)
    print(f"|  {bold('MODE')}    : {auto_s}{p}  |")

    sess_plain = f"[X] SESSION BLOCK  {sl}  — no bets" if sb else ("─ session filter OFF" if not SESSION_BLOCK_ENABLED else "OK clear (no session block)")
    p = pad(2 + len("SESSION : ") + len(sess_plain), W - 2)
    print(f"|  {bold('SESSION')} : {sess_s}{p}  |")

    #keys_plain = "[U] bet UP  [D] bet DOWN  [A] toggle auto  (Win/Linux)"
    #p = pad(2 + len(keys_plain), W - 2)
    #print(f"|  {dim(keys_plain)}{p}  |")

    #print(SEP)
    #logs_plain = "Logs: logs/late_live.log | logs/late_live_results.csv"
    #p = pad(2 + len(logs_plain), W - 2)
    #print(f"|  {dim(logs_plain)}{p}  |")
    #print(SEP)
    #print(f"  {dim('Ctrl+C to stop')}\n")


# ─────────────────────────────────────────────
# Keyboard Listener
# ─────────────────────────────────────────────
async def keyboard_listener(handler: LateHandler):
    """Non-blocking keyboard. Windows: msvcrt. Linux: termios raw mode."""
    loop = asyncio.get_event_loop()

    def _handle_key(ch: str):
        ch = ch.lower()
        if ch == "u":
            asyncio.run_coroutine_threadsafe(handler.manual_bet("UP"), loop)
        elif ch == "d":
            asyncio.run_coroutine_threadsafe(handler.manual_bet("DOWN"), loop)
        elif ch == "a":
            handler.auto_enabled = not handler.auto_enabled
            state = "ON" if handler.auto_enabled else "OFF"
            handler._manual_msg = f"Auto: {state}"
            logger.warning(f"[KB] Auto-bet {state}")
        elif ch == "\x03":
            raise KeyboardInterrupt

    if sys.platform == "win32":
        logger.info("[KB] Windows [U]=UP [D]=DOWN [A]=toggle")
        while True:
            try:
                if msvcrt.kbhit():
                    raw = msvcrt.getch()
                    try:
                        _handle_key(raw.decode("utf-8"))
                    except (UnicodeDecodeError, KeyboardInterrupt):
                        pass
                    await asyncio.sleep(0.3)
            except Exception as e:
                logger.debug(f"[KB] {e}")
            await asyncio.sleep(0.05)
    else:
        import termios, tty, select
        fd           = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        logger.info("[KB] Linux [U]=UP [D]=DOWN [A]=toggle")
        try:
            tty.setcbreak(fd)
            while True:
                try:
                    ready, _, _ = select.select([sys.stdin], [], [], 0.05)
                    if ready:
                        ch = sys.stdin.read(1)
                        _handle_key(ch)
                        await asyncio.sleep(0.3)
                except KeyboardInterrupt:
                    raise
                except Exception as e:
                    logger.debug(f"[KB] {e}")
                await asyncio.sleep(0.05)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)


# ─────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────
async def main():
    start_time = time.time()
    mode_label = "DRY RUN" if DRY_RUN else "*** LIVE TRADING ***"

    print(f"\n{'='*64}")
    print(f"  POLYMARKET LATE BOT  {BOT_VERSION}")
    print(f"  Mode       : {mode_label}")
    print(f"  Entry zone : t={ENTRY_WINDOW_START}-{300-MIN_WINDOW_REMAINING}s (last 90s)")
    print(f"  Beat dist  : UP>=${MIN_BEAT_DISTANCE_UP:.0f}  DN>=${MIN_BEAT_DISTANCE_DOWN:.0f}")
    print(f"  Liq r/s    : ${LIQ_RECENT_MIN_USD:,.0f} / ${LIQ_SUSTAINED_MIN_USD:,.0f}")
    print(f"  CVD 30s/2m : ${CVD_SHORT_THRESHOLD:,.0f} / ${CVD_MIN_THRESHOLD:,.0f}")
    print(f"  Bet        : ${BET_AMOUNT:.2f} flat  max {MAX_BETS_PER_HOUR}/hr")
    print(f"{'='*64}\n")

    if not DRY_RUN:
        # Skip konfirmasi jika auto-restart (env BOT_CONFIRMED=1 di-set otomatis)
        already_confirmed = os.getenv("BOT_CONFIRMED", "0") == "1"
        if not already_confirmed:
            confirm = input("  Type 'LIVE' to confirm: ").strip()
            if confirm != "LIVE":
                print("  Cancelled.")
                return
            # Set env var agar restart otomatis tidak tanya lagi
            os.environ["BOT_CONFIRMED"] = "1"
        else:
            print(f"  Auto-restart terdeteksi — skip konfirmasi LIVE.")
        print()

    # ── Init ──
    data    = MarketData()
    ws      = HyperliquidWSFetcher(data)
    rest    = HyperliquidRESTFetcher(data, poll_interval=5)
    tracker = ResultTracker(data, "logs/late_live_results.csv")
    candle  = CandleTracker(history_size=20)

    blocked_tracker = BlockedTracker(data, "logs/late_live_blocked.csv")
    executor        = PolymarketExecutor(dry_run=DRY_RUN, min_odds=MIN_ODDS)

    market_cache = {
        "market"           : None,
        "question"         : "─ waiting...",
        "refreshed_at"     : 0.0,
        "yes_px"           : 0.0,
        "no_px"            : 0.0,
        "odds_refreshed_at": 0.0,
        "odds_valid"       : False,
        "next_question"    : "",
        "next_secs"        : 0.0,
    }

    handler = LateHandler(
        tracker      = tracker,
        candle       = candle,
        data         = data,
        blocked      = blocked_tracker,
        executor     = executor,
        market_cache = market_cache,
    )

    engine = SignalEngine(
        market_data         = data,
        liq_threshold_usd   = LIQ_THRESHOLD,
        eval_interval       = 1.0,
        log_path            = "logs/late_live_signals.csv",
        log_only_actionable = False,
    )
    engine._running = True
    engine.on_signal(handler.on_signal)

    async def candle_update_loop():
        while True:
            if data.btc_price > 0:
                candle.update(data.btc_price)
            await asyncio.sleep(1)

    claim_state = {
        "status":       "",
        "last_balance": 999.0,
        "pusd_bal":     0.0,    # saldo pUSD — diupdate oleh autoclaim_and_wrap
    }

    # ── Launch tasks ──
    logger.warning(f"[BOT] Starting {BOT_VERSION} | DRY_RUN={DRY_RUN} | MIN_BET_ODDS={MIN_BET_ODDS}")
    ws_task      = asyncio.create_task(ws.start())   # FIX: ws_task harus ada sebelum loop
    rest_task    = asyncio.create_task(rest.start())
    tracker_task = asyncio.create_task(tracker.run_loop())
    engine_task  = asyncio.create_task(engine.run_loop())
    blocked_task = asyncio.create_task(blocked_tracker.run_loop())
    candle_task  = asyncio.create_task(candle_update_loop())
    cache_task   = asyncio.create_task(_market_refresh_loop(executor, market_cache))
    claim_task   = asyncio.create_task(_auto_claim_loop(executor, claim_state, tracker))
    kb_task      = asyncio.create_task(keyboard_listener(handler))

    _prev_blocked  = 0
    _ws_err_since  = 0.0   # timestamp pertama kali WS terdeteksi ERR (0 = OK)

    try:
        while True:
            elapsed = CandleTracker.get_time_elapsed()
            handler.update_filters_live()

            refresh_interval = 1 if elapsed >= ENTRY_WINDOW_START else 5
            await asyncio.sleep(refresh_interval)

            # ── WS Watchdog ──
            # Jika WS ERR > WS_RESTART_SEC → cancel task dan restart fresh.
            # Mengatasi DNS glitch / HTTP 502 yang bikin reconnect loop stuck.
            now = time.time()
            if not data.ws_connected:
                if _ws_err_since == 0.0:
                    _ws_err_since = now
                    logger.warning("[WATCHDOG] WS ERR terdeteksi — mulai hitung...")
                elif now - _ws_err_since >= WS_RESTART_SEC:
                    err_dur = int(now - _ws_err_since)
                    logger.warning(f"[WATCHDOG] WS ERR {err_dur}s — restart ws_task")
                    # stop() reset _running dan _fail_count
                    # CancelledError di-handle di dalam ws.start() → return bersih
                    ws.stop()
                    ws_task.cancel()
                    # Tidak perlu await ws_task — CancelledError sudah di-handle
                    await asyncio.sleep(2)
                    ws_task       = asyncio.create_task(ws.start())
                    _ws_err_since = 0.0
                    asyncio.create_task(play_sound("warning"))
                    logger.warning("[WATCHDOG] ws_task di-restart")
            else:
                if _ws_err_since != 0.0:
                    rec_sec = int(now - _ws_err_since)
                    logger.warning(f"[WATCHDOG] WS kembali OK setelah {rec_sec}s")
                _ws_err_since = 0.0

            cur_blocked = blocked_tracker.stats["total"]
            if cur_blocked > _prev_blocked:
                asyncio.create_task(play_sound("blocked"))
                _prev_blocked = cur_blocked

            uptime  = time.time() - start_time
            balance = executor.get_balance()
            claim_state["last_balance"] = balance

            print_late_dashboard(
                data, engine, tracker, uptime,
                candle, handler, blocked_tracker,
                market_cache  = market_cache,
                balance       = balance,
                claim_status  = claim_state["status"],
                claim_state   = claim_state,
                ws_err_since  = _ws_err_since,
            )

    except KeyboardInterrupt:
        print("\n\n  Stopping...")

    finally:
        engine.stop()
        tracker.stop()
        ws.stop()
        rest.stop()
        blocked_tracker.stop()
        for t in [
            ws_task, rest_task, tracker_task, engine_task,
            blocked_task, candle_task, cache_task, claim_task, kb_task,
        ]:
            t.cancel()
            try:
                await t
            except (asyncio.CancelledError, Exception):
                pass

        stats    = tracker.stats
        duration = time.time() - start_time
        print(f"\n{'='*64}")
        print(f"  LATE BOT {BOT_VERSION} STOPPED")
        print(f"  Duration  : {int(duration//60)}m {int(duration%60)}s")
        print(f"  Bets      : {stats['total']}  W:{stats['wins']} L:{stats['losses']}")
        print(f"  Pending   : {stats['pending']}")
        print(f"  Win Rate  : {stats['win_rate']:.1f}%")
        print(f"  Total PnL : ${stats['total_pnl']:+.2f}")
        print(f"{'='*64}\n")


if __name__ == "__main__":
    import traceback

    # Auto-restart loop: jika bot crash (bukan Ctrl+C), restart otomatis setelah 5s.
    # Konfirmasi "LIVE" hanya diminta pertama kali — restart berikutnya skip otomatis
    # karena BOT_CONFIRMED=1 sudah di-set di os.environ oleh main() pertama.
    while True:
        try:
            asyncio.run(main())
            # main() keluar normal (Ctrl+C) → berhenti
            break
        except KeyboardInterrupt:
            print("\n  Bot dihentikan manual.")
            break
        except Exception as e:
            print(f"\n  [CRASH] Bot crash: {e}")
            traceback.print_exc()
            print(f"  Bot crashed, restarting in 5s...")
            time.sleep(5)
